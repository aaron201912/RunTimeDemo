#include <signal.h>
#include <pthread.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <getopt.h>

#include "mi_common.h"
#include "mi_common_datatype.h"
#include "mi_sys.h"
#include "mi_sys_datatype.h"
#include "mi_panel_datatype.h"

#include "common.h"
#include "sstardisp.h"
#include "sstarvdec.h"
#include "sstaradec.h"


static char g_video_file[256];
static char g_audio_file[256];


static MI_S32 g_audio_enable=false;
static MI_S32 g_video_enable=false;


void display_help(void)
{
    printf("************************* Video usage *************************\n");
    printf("--vpath : Video file path\n");
    printf("-X : Video x coordinate,default value is 0\n");
    printf("-Y : Video y coordinate,default value is 0\n");
    printf("-W : Video with\n");
    printf("-H : Video height\n");
    printf("-R : Video rotate choice:[0-4]0=NONE,1=rotate_90,1=rotate_180,1=rotate_270\n");
    printf("-N : Video Port Num:[0-4]\n");
    printf("-P : PIP ,Enable pip:[0/1]\n");
    printf("eg:./SsPlayer  --vpath 720P25.h264 -X 0 -Y 0 -W 1024 -H 600 -R 0 -N 3 -P 1\n");

    printf("************************* Audio usage *************************\n");
    printf("--apath : Audio file path\n");
    printf("-s : Audio sample rate:\n");
    printf("-c : Audio channel mode:0=MONO,1=STEREO\n");
    printf("-v : Audio volume:[-60db-30db]\n");

    printf("eg:./SsPlayer --apath res/48k_stereo.wav -c 2 -s 48000 -v -10\n");

    return;
}


int parse_args(int argc, char **argv)
{
    int option_index=0;
    MI_S32 s32Opt = 0;

    struct option long_options[] = {
            {"vpath", required_argument, NULL, 'V'},
            {"apath", required_argument, NULL, 'a'},
            {"hdmi", no_argument, NULL, 'M'},
            {"help", no_argument, NULL, 'h'},
            {0, 0, 0, 0}
    };

    while ((s32Opt = getopt_long(argc, argv, "X:Y:W:H:Y:R:N:P:s:c:v:h",long_options, &option_index))!= -1 )
    {
        switch(s32Opt)
        {

            //video
            case 'V':
            {
                if(strlen(optarg) != 0)
                {
                   strcpy(g_video_file,optarg);
                   g_video_enable = true;
                }
                break;
            }
            case 'X':
            {
                OutX= atoi(optarg);
                break;
            }
            case 'Y':
            {
                OutY= atoi(optarg);
                break;
            }
            case 'W':
            {
                OutDispWidth = atoi(optarg);
                inDispWidth  = OutDispWidth;
                break;
            }
            case 'H':
            {
                OutDispHeight= atoi(optarg);
                inDispHeight = OutDispHeight;
                break;
            }
            case 'R':
            {
                bRota = (MI_DISP_RotateMode_e)atoi(optarg);
                break;
            }
            case 'N':
            {
                g_vdec_num = atoi(optarg);
                if(g_vdec_num > 4)
                {
                    printf("param error g_vdec_num=%d,-N param should be less than 4\n",g_vdec_num);
                    return -1;
                }
                break;
            }
            case 'P':
            {
                g_enable_pip = atoi(optarg);
                printf("g_enable_pip=%d \n",g_enable_pip);
                break;
            }

            //audio
            case 'a':
            {
                if(strlen(optarg) != 0)
                {
                   strcpy(g_audio_file,optarg);
                   g_audio_enable = true;
                }
                break;
            }
            case 's':
            {
                s32SampleRate = atoi(optarg);
                printf("s32SampleRate = %d\n",s32SampleRate);
                break;
            }
            case 'c':
            {
                s32SoundLayout = atoi(optarg);
                if(s32SoundLayout > 2)
                {
                    printf("param error s32SoundLayout=%d,-c param should be 1/2\n",s32SoundLayout);
                    return -1;
                }
                break;
            }
            case 'v':
            {
                g_audio_volume = atoi(optarg);
                printf("g_audio_volume = %d\n",g_audio_volume);
                break;
            }
            case '?':
            {
                if(optopt == 'V')
                {
                    printf("Missing Video file path, please --vpath 'video_path' \n");
                }
                if(optopt == 'a')
                {
                    printf("Missing Audio file path, please --apath 'audio_path' \n");
                }
                return -1;
                break;
            }
            case 'h':
            default:
            {
                display_help();
                return -1;
                break;
            }
        }
    }
    return 0;

}


int main (int argc, char **argv)
{
    pthread_t tid_audio;
    pthread_t tid_video;

    if(argc <= 1 )
    {
        display_help();
        return 0;
    }
    if(parse_args(argc, argv) != 0)
    {
        return 0;
    }
    if((bRota == E_MI_DISP_ROTATE_90 || bRota == E_MI_DISP_ROTATE_270) && g_vdec_num > 0)
    {//HW Rotate模式下,每个layer只能inputport0旋转,hw limit(180是gfx做的不受限制)
        if(g_vdec_num != 1 || g_enable_pip != 1)
        {
            printf("Hw limit,each layer only support one port(port0) with hw rotate(E_MI_DISP_ROTATE_90/270)\n");
            return 0;
        }
    }

    if(g_vdec_num > 4)
    {
        printf("Invail Param with -N=%d ，should be less than 4  \n",g_vdec_num);
        return 0;
    }
    else if((g_vdec_num > 3) && (g_enable_pip == 1))//limit
    {
        printf("Disable Pip,VChan_num is:%d,should be less than 4 total\n",g_vdec_num);
        g_enable_pip = 0;
    }
    else if((g_vdec_num == 0) && (g_enable_pip == 0))
    {
        g_vdec_num = 1;
    }


    MI_DISP_PubAttr_t stDispPubAttr;
#if ENABLE_HDMI
    stDispPubAttr.eIntfType = E_MI_DISP_INTF_HDMI;
#else
    stDispPubAttr.eIntfType = E_MI_DISP_INTF_LCD;
#endif
    stDispPubAttr.eIntfSync = E_MI_DISP_OUTPUT_USER;
    sstar_disp_init(&stDispPubAttr, g_vdec_num);

    sstar_vdec_init(g_vdec_num);

    sstar_disp_set_rotatemode(bRota);

    if (g_audio_enable) {
        sstar_ao_init();
        pthread_create(&tid_audio, NULL, sstar_audio_thread, (void *)g_audio_file);
    }

    if (g_video_enable) {
        pthread_create(&tid_video, NULL, sstar_video_thread, (void *)g_video_file);
    }

    while (!bExit)
    {
        printf("please input 'q' to exit\n");
        if(getchar() == 'q')
        {
            bExit = TRUE;
            printf("### H264Player Exit ###\n");
        }
    }

    if (g_video_enable) {
        pthread_join(tid_video, NULL);
    }

    if (g_audio_enable) {
        pthread_join(tid_audio, NULL);
        sstar_ao_deinit();
    }

    sstar_disp_Deinit(&stDispPubAttr, g_vdec_num);
    sstar_vdec_deInit(g_vdec_num);

    return 0;
}
