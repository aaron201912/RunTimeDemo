#ifndef __DEMUX_H__
#define __DEMUX_H__

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus


#include "player.h"

int open_demux(player_stat_t *is);

#ifdef __cplusplus
}
#endif // __cplusplus


#endif
