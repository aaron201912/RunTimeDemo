#ifndef __SSTARDISP__H__
#define __SSTARDISP__H__

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

#include "stdbool.h"

#include <mi_disp_datatype.h>
#ifdef CONFIG_DEMO_ENABLE_HDMI
#include "mi_hdmi.h"
typedef struct stTimingArray_s
{
    char desc[50];
    MI_DISP_OutputTiming_e eOutputTiming;
    MI_HDMI_TimingType_e eHdmiTiming;
    MI_U16 u16Width;
    MI_U16 u16Height;
}stTimingArray_t;
#endif
typedef enum
{
    ST_DBG_NONE = 0,
    ST_DBG_ERR,
    ST_DBG_WRN,
    ST_DBG_INFO,
    ST_DBG_DEBUG,
    ST_DBG_ALL
}ST_DBG_LEVEL_e;

#define ASCII_COLOR_RED                          "\033[1;31m"
#define ASCII_COLOR_WHITE                        "\033[1;37m"
#define ASCII_COLOR_YELLOW                       "\033[1;33m"
#define ASCII_COLOR_BLUE                         "\033[1;36m"
#define ASCII_COLOR_GREEN                        "\033[1;32m"
#define ASCII_COLOR_END                          "\033[0m"

#define DBG_DEBUG(fmt, args...)     ({do{if(g_eSTDbgLevel>=ST_DBG_DEBUG){printf(ASCII_COLOR_GREEN"[APP INFO]:%s[%d]: " fmt ASCII_COLOR_END, __FUNCTION__,__LINE__,##args);}}while(0);})
#define DBG_INFO(fmt, args...)      ({do{if(g_eSTDbgLevel>=ST_DBG_INFO){printf(ASCII_COLOR_GREEN"[APP INFO]:%s[%d]: " fmt ASCII_COLOR_END, __FUNCTION__,__LINE__,##args);}}while(0);})
#define DBG_WRN(fmt, args...)       ({do{if(g_eSTDbgLevel>=ST_DBG_WRN){printf(ASCII_COLOR_YELLOW"[APP WRN ]: %s[%d]: " fmt ASCII_COLOR_END, __FUNCTION__,__LINE__, ##args);}}while(0);})
#define DBG_ERR(fmt, args...)       ({do{if(g_eSTDbgLevel>=ST_DBG_ERR){printf(ASCII_COLOR_RED"[APP ERR ]: %s[%d]: " fmt ASCII_COLOR_END, __FUNCTION__,__LINE__, ##args);}}while(0);})
#define DBG_EXIT_ERR(fmt, args...)  ({do{printf(ASCII_COLOR_RED"<<<%s[%d] " fmt ASCII_COLOR_END,__FUNCTION__,__LINE__,##args);}while(0);})
#define DBG_ENTER()                 ({do{if(g_bSTFuncTrace){printf(ASCII_COLOR_BLUE">>>%s[%d] \n" ASCII_COLOR_END,__FUNCTION__,__LINE__);}}while(0);})
#define DBG_EXIT_OK()               ({do{if(g_bSTFuncTrace){printf(ASCII_COLOR_BLUE"<<<%s[%d] \n" ASCII_COLOR_END,__FUNCTION__,__LINE__);}}while(0);})

extern bool g_rotate;

int sstar_disp_init(MI_DISP_PubAttr_t* pstDispPubAttr,int inputwidth,int inputheight);
int sstar_disp_Deinit(MI_DISP_PubAttr_t *pstDispPubAttr);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif //__SSTARDISP__H__
