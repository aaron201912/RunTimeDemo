#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"

#include "mi_sys.h"
#include "sstardisp.h"
#include "SsPlayer.h"

#include "mi_panel_datatype.h"
#include "mi_panel.h"
#include "mi_disp_datatype.h"
#include "mi_disp.h"
#ifdef CONFIG_DEMO_ENABLE_HDMI_USE_EXTRA_LIB
#include "edid.h"
#endif
//#include <config.h>
#define UI_1024_600 1
#define USE_MIPI    0

#if UI_1024_600
#include "SAT070CP50_1024x600.h"
#else
#if USE_MIPI
#include "EK79007_1024x600_MIPI.h"
#else
#include "SAT070AT50_800x480.h"
#endif
#endif

// loacl play res
#if UI_1024_600
//#define LOCAL_VIDEO_W  822
//#define LOCAL_VIDEO_H  464
//#define LOCAL_VIDEO_X  100
//#define LOCAL_VIDEO_Y  60
#define LOCAL_VIDEO_W  1024
#define LOCAL_VIDEO_H  600
#define LOCAL_VIDEO_X  0
#define LOCAL_VIDEO_Y  0
#else
//#define LOCAL_VIDEO_W  640
//#define LOCAL_VIDEO_H  360
//#define LOCAL_VIDEO_X  100
//#define LOCAL_VIDEO_Y  60
#define LOCAL_VIDEO_W  800
#define LOCAL_VIDEO_H  480
#define LOCAL_VIDEO_X  0
#define LOCAL_VIDEO_Y  0
#endif

#if defined(__cplusplus)||defined(c_plusplus)
extern "C"{
#endif
#define STCHECKRESULT(result)\
    if (result != MI_SUCCESS)\
    {\
        printf("[%s %d]exec function failed\n", __FUNCTION__, __LINE__);\
        return 1;\
    }\
    else\
    {\
        printf("(%s %d)exec function pass\n", __FUNCTION__,__LINE__);\
    }

ST_DBG_LEVEL_e g_eSTDbgLevel = ST_DBG_ALL;
MI_BOOL g_bSTFuncTrace = 0;
#define ARRAY_SIZE(x) (sizeof(x)/sizeof(x[0]))

#ifdef CONFIG_DEMO_ENABLE_HDMI
#define HDMI_EDID_SIZE  256
MI_HDMI_SinkInfo_t g_stHDMISinkInfo = {0};
MI_HDMI_Edid_t g_stHDMIEdid = {0};

#ifdef CONFIG_DEMO_ENABLE_HDMI_USE_EXTRA_LIB
MI_U8 g_auEDIDBuffer[HDMI_EDID_SIZE] = {0};
struct edid *g_pstEdid = (struct edid *)g_auEDIDBuffer;//edid(128 bytes)+edid_extension(128 bytes)
extern void parse_edid(const uint8_t * const data);
extern char* ST_EdidTimingString(const struct edid_detailed_timing_descriptor * const dtb);
#endif
stTimingArray_t astTimingArray[] = {
    {
        .desc = "user",
        .eOutputTiming = E_MI_DISP_OUTPUT_USER,
        .eHdmiTiming = E_MI_HDMI_TIMING_MAX,
    },
    {
        .desc = "480p60",
        .eOutputTiming = E_MI_DISP_OUTPUT_480P60,
        .eHdmiTiming = E_MI_HDMI_TIMING_480_60P,
        .u16Width = 640,
        .u16Height = 480
    },
    {
        .desc = "576p50",
        .eOutputTiming = E_MI_DISP_OUTPUT_576P50,
        .eHdmiTiming = E_MI_HDMI_TIMING_576_50P,
        .u16Width = 720,
        .u16Height = 576
    },
    {
        .desc = "720p50",
        .eOutputTiming = E_MI_DISP_OUTPUT_720P50,
        .eHdmiTiming = E_MI_HDMI_TIMING_720_50P,
        .u16Width = 1280,
        .u16Height = 720
    },
    {
        .desc = "720p60",
        .eOutputTiming = E_MI_DISP_OUTPUT_720P60,
        .eHdmiTiming = E_MI_HDMI_TIMING_720_60P,
        .u16Width = 1280,
        .u16Height = 720
    },
    {
        .desc = "1024x768_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1024x768_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1024x768_60P,
        .u16Width = 1024,
        .u16Height = 768
    },
    {
        .desc = "1080p24",
        .eOutputTiming = E_MI_DISP_OUTPUT_1080P24,
        .eHdmiTiming = E_MI_HDMI_TIMING_1080_24P,
        .u16Width = 1920,
        .u16Height = 1080
    },
    {
        .desc = "1080p25",
        .eOutputTiming = E_MI_DISP_OUTPUT_1080P25,
        .eHdmiTiming = E_MI_HDMI_TIMING_1080_25P,
        .u16Width = 1920,
        .u16Height = 1080
    },
    {
        .desc = "1080p30",
        .eOutputTiming = E_MI_DISP_OUTPUT_1080P30,
        .eHdmiTiming = E_MI_HDMI_TIMING_1080_30P,
        .u16Width = 1920,
        .u16Height = 1080
    },
    {
        .desc = "1080p50",
        .eOutputTiming = E_MI_DISP_OUTPUT_1080P50,
        .eHdmiTiming = E_MI_HDMI_TIMING_1080_50P,
        .u16Width = 1920,
        .u16Height = 1080
    },
    {
        .desc = "1080p60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1080P60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1080_60P,
        .u16Width = 1920,
        .u16Height = 1080
    },
    {
        .desc = "1280x800_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1280x800_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1280x800_60P,
        .u16Width = 1280,
        .u16Height = 800
    },
    {
        .desc = "1280x1024_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1280x1024_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1280x1024_60P,
        .u16Width = 1280,
        .u16Height = 1024
    },
    {
        .desc = "1366x768_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1366x768_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1366x768_60P,//HDMI don't support this timing
        .u16Width = 1366,
        .u16Height = 768
    },
    {
        .desc = "1440x900_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1440x900_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1440x900_60P,
        .u16Width = 1440,
        .u16Height = 900
    },
    {
        .desc = "1680x1050_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1680x1050_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1680x1050_60P,//HDMI don't support this timing
        .u16Width = 1680,
        .u16Height = 1050
    },
    {
        .desc = "1600x1200_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_1600x1200_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_1600x1200_60P,
        .u16Width = 1600,
        .u16Height = 1200
    },
    {
        .desc = "2560x1440_30",
        .eOutputTiming = E_MI_DISP_OUTPUT_2560x1440_30,
         .eHdmiTiming = E_MI_HDMI_TIMING_MAX,//HDMI don't support this timing
        .u16Width = 2560,
        .u16Height = 1440
    },
    {
        .desc = "2560x1440_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_MAX,//not defined
         .eHdmiTiming = E_MI_HDMI_TIMING_MAX,//HDMI don't support this timing
        .u16Width = 2560,
        .u16Height = 1440
    },
    {
        .desc = "2560x1600_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_2560x1600_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_MAX,//HDMI don't support this timing
        .u16Width = 2560,
        .u16Height = 1600
    },
    {
        .desc = "3840x2160_30",
        .eOutputTiming = E_MI_DISP_OUTPUT_3840x2160_30,
        .eHdmiTiming = E_MI_HDMI_TIMING_4K2K_30P,
        .u16Width = 3840,
        .u16Height = 2160
    },
    {
        .desc = "3840x2160_60",
        .eOutputTiming = E_MI_DISP_OUTPUT_3840x2160_60,
        .eHdmiTiming = E_MI_HDMI_TIMING_4K2K_60P,
        .u16Width = 3840,
        .u16Height = 2160
    },
};
static void ST_GetLayerDisplaySize(MI_DISP_OutputTiming_e eOutputTiming, MI_U32 *LayerDisplayWidth, MI_U32 *LayerDisplayHeight)
{
    MI_U32 u32Index = 0;
    MI_U32 u32ArraySize = ARRAY_SIZE(astTimingArray);
    
    if(eOutputTiming == E_MI_DISP_OUTPUT_USER)
    {
        *LayerDisplayWidth = stPanelParam.u16Width;
        *LayerDisplayHeight = stPanelParam.u16Height;
        return;
    }
    for(u32Index=0; u32Index < u32ArraySize; u32Index++)
    {
        if(eOutputTiming == astTimingArray[u32Index].eOutputTiming)
        {
            *LayerDisplayWidth = astTimingArray[u32Index].u16Width;
            *LayerDisplayHeight = astTimingArray[u32Index].u16Height;
            return;
        }
    }
    if(u32Index == u32ArraySize)
    {
        DBG_ERR("invalid outputtiming\n");
    }
}

static MI_HDMI_TimingType_e ST_GetHdmiTiming(MI_DISP_OutputTiming_e eOutputTiming)
{
    MI_U32 u32Index = 0;
    MI_U32 u32ArraySize = ARRAY_SIZE(astTimingArray);
    MI_HDMI_TimingType_e eHdmiTiming;

    for(u32Index=0; u32Index < u32ArraySize; u32Index++)
    {
        if(eOutputTiming == astTimingArray[u32Index].eOutputTiming)
        {
            eHdmiTiming = astTimingArray[u32Index].eHdmiTiming;
            break;
        }
    }
    return eHdmiTiming;
}

static MI_S32 Hdmi_callback_impl(MI_HDMI_DeviceId_e eHdmi, MI_HDMI_EventType_e Event, void *pEventParam, void *pUsrParam)
{
    switch (Event)
    {
        case E_MI_HDMI_EVENT_HOTPLUG:
            DBG_INFO("E_MI_HDMI_EVENT_HOTPLUG.\n");
            break;
        case E_MI_HDMI_EVENT_NO_PLUG:
            DBG_INFO("E_MI_HDMI_EVENT_NO_PLUG.\n");
            break;
        default:
            printf("Unsupport event.\n");
            break;
    }

    return MI_SUCCESS;
}
MI_U16 ST_GetHdmitxTimingWidth(MI_DISP_OutputTiming_e eTimingType)
{
    MI_U16 u16Width = 0;
    if((E_MI_DISP_OUTPUT_1080P24 == eTimingType) || (E_MI_DISP_OUTPUT_1080P25 == eTimingType) || (E_MI_DISP_OUTPUT_1080P30 == eTimingType)
        || (E_MI_DISP_OUTPUT_1080I50 == eTimingType) || (E_MI_DISP_OUTPUT_1080I60 == eTimingType) || (E_MI_DISP_OUTPUT_1080P50 == eTimingType) || (E_MI_DISP_OUTPUT_1080P60 == eTimingType))
    {
        u16Width = 1920;
    }
    else if((E_MI_DISP_OUTPUT_3840x2160_30 == eTimingType) || (E_MI_DISP_OUTPUT_3840x2160_60 == eTimingType))
    {
        u16Width = 3840;
    }
    else
    {
        DBG_ERR("pls add timing[%d] width \n", eTimingType);
    }
    return u16Width;
}
MI_U16 ST_GetHdmitxTimingHeight(MI_DISP_OutputTiming_e eTimingType)
{
    MI_U16 u16Height = 0;
    if((E_MI_DISP_OUTPUT_1080P24 == eTimingType) || (E_MI_DISP_OUTPUT_1080P25 == eTimingType) || (E_MI_DISP_OUTPUT_1080P30 == eTimingType)
        || (E_MI_DISP_OUTPUT_1080I50 == eTimingType) || (E_MI_DISP_OUTPUT_1080I60 == eTimingType) || (E_MI_DISP_OUTPUT_1080P50 == eTimingType) || (E_MI_DISP_OUTPUT_1080P60 == eTimingType))
    {
        u16Height = 1080;
    }
    else if((E_MI_DISP_OUTPUT_3840x2160_30 == eTimingType) || (E_MI_DISP_OUTPUT_3840x2160_60 == eTimingType))
    {
        u16Height = 2160;
    }
    else
    {
        DBG_ERR("pls add timing[%d] height \n", eTimingType);
    }

    return u16Height;
}
MI_S32 ST_GetHDMITimingAndDISPTiming(MI_DISP_OutputTiming_e eInTimingType, MI_HDMI_TimingType_e *peOutHDMITimingType, MI_DISP_OutputTiming_e *peOutDISPOutputTiming)
{
    MI_S32 s32Ret = MI_SUCCESS;

    if(E_MI_DISP_OUTPUT_1080P60 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_60P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P60;
    }
    else if(E_MI_DISP_OUTPUT_1080P50 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_50P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P50;
    }
    else if(E_MI_DISP_OUTPUT_1080I60 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_60I;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080I60;
    }
    else if(E_MI_DISP_OUTPUT_1080I50 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_50I;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080I50;
    }
    else if(E_MI_DISP_OUTPUT_1080P30 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_30P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P30;
    }
    else if(E_MI_DISP_OUTPUT_1080P25 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_25P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P25;
    }
    else if(E_MI_DISP_OUTPUT_1080P24 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_24P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P24;
    }
    else if(E_MI_DISP_OUTPUT_3840x2160_60 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_4K2K_60P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_3840x2160_60;
    }
    else if(E_MI_DISP_OUTPUT_3840x2160_30 == eInTimingType)
    {
        *peOutHDMITimingType = E_MI_HDMI_TIMING_4K2K_30P;
        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_3840x2160_30;
    }
    else
    {
        DBG_ERR("pls add timing[%d] relation \n", eInTimingType);
    }
    
    DBG_INFO("user set HDMITimingType[%d], DISPTiming[%d] \n", *peOutHDMITimingType, *peOutDISPOutputTiming);
    return s32Ret;
}
MI_S32 ST_GetPreferredTimingFromEDID(MI_HDMI_TimingType_e *peOutHDMITimingType, MI_DISP_OutputTiming_e *peOutDISPOutputTiming)
{
    MI_S32 s32Ret = MI_SUCCESS;
    char *string = NULL;
    MI_U32 u32Index = 0;
    MI_U32 u32ArraySize = ARRAY_SIZE(astTimingArray);
    
    s32Ret = MI_HDMI_GetSinkInfo(E_MI_HDMI_ID_0, &g_stHDMISinkInfo);
    if(MI_SUCCESS == s32Ret)
    {
        DBG_INFO("bConnected=%d,bSupportHdmi=%d,eNativeTimingType=%d,u8Version=%d \n",g_stHDMISinkInfo.bConnected, g_stHDMISinkInfo.bSupportHdmi, g_stHDMISinkInfo.eNativeTimingType, g_stHDMISinkInfo.u8Version);
        #ifdef CONFIG_DEMO_ENABLE_HDMI_USE_EXTRA_LIB
        s32Ret = MI_HDMI_ForceGetEdid(E_MI_HDMI_ID_0, &g_stHDMIEdid);
        if(MI_SUCCESS == s32Ret)
        {
            DBG_INFO("MI_HDMI_ForceGetEdid:bEdidValid:%d, Edidlength:%d \n", g_stHDMIEdid.bEdidValid, g_stHDMIEdid.u32Edidlength);
            if(HDMI_EDID_SIZE == g_stHDMIEdid.u32Edidlength)
            {
                memcpy(g_auEDIDBuffer, g_stHDMIEdid.au8Edid,g_stHDMIEdid.u32Edidlength);
                parse_edid(g_auEDIDBuffer);
                if(1 == g_pstEdid->feature_support.preferred_timing_mode)
                {
                    string = ST_EdidTimingString(&g_pstEdid->detailed_timings[0].timing);
                    DBG_INFO("find Native/preferred timing:%s\n", string);
                    //if user modify here, need modify ST_GetHdmitxTimingHeight and ST_GetHdmitxTimingWidth
                    if(0 == strcmp(string,"1920x1080p_60Hz"))
                    {
                        DBG_INFO("set OutputTiming 1920x1080p_60Hz \n");
                        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_60P;
                        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P60;
                    }
                    else if(0 == strcmp(string,"1920x1080p_50Hz"))
                    {
                        DBG_INFO("set OutputTiming 1920x1080p_50Hz \n");
                        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_50P;
                        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080P50;
                    }
                    else if(0 == strcmp(string,"1920x1080i_60Hz"))
                    {
                        DBG_INFO("set OutputTiming 1920x1080i_60Hz \n");
                        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_60I;
                        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080I60;
                    }
                    else if(0 == strcmp(string,"1920x1080i_50Hz"))
                    {
                        DBG_INFO("set OutputTiming 1920x1080i_50Hz \n");
                        *peOutHDMITimingType = E_MI_HDMI_TIMING_1080_50I;
                        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_1080I50;
                    }
                    else if(0 == strcmp(string,"3840x2160p_30Hz"))
                    {
                        DBG_INFO("set OutputTiming 3840x2160p_30Hz \n");
                        *peOutHDMITimingType = E_MI_HDMI_TIMING_4K2K_30P;
                        *peOutDISPOutputTiming = E_MI_DISP_OUTPUT_3840x2160_30;
                    }
                    free(string);
                    string = NULL;
                }
                else
                {
                    DBG_WRN("not find Native/preferred timing \n");
                }
            }
            else
            {
                s32Ret = 1;
                DBG_ERR("ForceGetEdid, size[%d] not is 256 \n", g_stHDMIEdid.u32Edidlength);
            }
        }
        else
        {
            //s32Ret = 1;
            DBG_ERR("can't ForceGetEdid, get edid fail \n");
        }
        #else
        DBG_INFO("get edid timing>>>>>>>>>>>>>>>>>>>>>\n");
        for(u32Index=0; u32Index < u32ArraySize; u32Index++)
        {
            if(E_MI_HDMI_TIMING_MAX != astTimingArray[u32Index].eHdmiTiming)
            {
                DBG_INFO("EDID Timing[%s][%d] \n", astTimingArray[u32Index].desc, g_stHDMISinkInfo.abVideoFmtSupported[astTimingArray[u32Index].eHdmiTiming]);
            }
        }
        DBG_INFO("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<end\n");
        #endif
    }
    else
    {
        //s32Ret = 1;
        DBG_ERR("can't get SinkInfo, get edid fail \n");
    }

    return s32Ret;
}
#endif
int sstar_disp_init(MI_DISP_PubAttr_t *pstDispPubAttr,int inputwidth,int inputheight)
{
    MI_PANEL_LinkType_e eLinkType;
    MI_DISP_InputPortAttr_t stInputPortAttr;
#ifdef CONFIG_DEMO_ENABLE_HDMI 
    MI_HDMI_InitParam_t stInitParam;
    MI_HDMI_Attr_t stAttr;
    MI_DISP_VideoLayerAttr_t stLayerAttr;
    MI_HDMI_TimingType_e eHDMITimingType = 0;
    MI_DISP_OutputTiming_e eDISPOutputTiming = 0;
    MI_U32 u32LayerDispWidth = 0,u32LayerDispHeight = 0;
#endif
    MI_S32 s32Ret = MI_SUCCESS;
    memset(&stInputPortAttr, 0, sizeof(stInputPortAttr));
#ifdef CONFIG_DEMO_ENABLE_HDMI
    memset(&stInitParam, 0, sizeof(stInitParam));
    memset(&stAttr, 0, sizeof(stAttr));
    memset(&stLayerAttr, 0, sizeof(stLayerAttr));
    memset(&g_stHDMISinkInfo, 0, sizeof(g_stHDMISinkInfo));
    memset(&g_stHDMIEdid, 0, sizeof(g_stHDMIEdid));
    #ifdef CONFIG_DEMO_ENABLE_HDMI_USE_EXTRA_LIB
    memset(&g_auEDIDBuffer, 0, sizeof(g_auEDIDBuffer));
    #endif
#endif

    MI_SYS_Init();

    if (pstDispPubAttr->eIntfType == E_MI_DISP_INTF_LCD)
    {
        pstDispPubAttr->stSyncInfo.u16Vact = stPanelParam.u16Height;
        pstDispPubAttr->stSyncInfo.u16Vbb = stPanelParam.u16VSyncBackPorch;
        pstDispPubAttr->stSyncInfo.u16Vfb = stPanelParam.u16VTotal - (stPanelParam.u16VSyncWidth +
                                                                      stPanelParam.u16Height + stPanelParam.u16VSyncBackPorch);
        pstDispPubAttr->stSyncInfo.u16Hact = stPanelParam.u16Width;
        pstDispPubAttr->stSyncInfo.u16Hbb = stPanelParam.u16HSyncBackPorch;
        pstDispPubAttr->stSyncInfo.u16Hfb = stPanelParam.u16HTotal - (stPanelParam.u16HSyncWidth +
                                                                      stPanelParam.u16Width + stPanelParam.u16HSyncBackPorch);
        pstDispPubAttr->stSyncInfo.u16Bvact = 0;
        pstDispPubAttr->stSyncInfo.u16Bvbb = 0;
        pstDispPubAttr->stSyncInfo.u16Bvfb = 0;
        pstDispPubAttr->stSyncInfo.u16Hpw = stPanelParam.u16HSyncWidth;
        pstDispPubAttr->stSyncInfo.u16Vpw = stPanelParam.u16VSyncWidth;
        pstDispPubAttr->stSyncInfo.u32FrameRate = stPanelParam.u16DCLK * 1000000 / (stPanelParam.u16HTotal * stPanelParam.u16VTotal);
        pstDispPubAttr->eIntfSync = E_MI_DISP_OUTPUT_USER;
        pstDispPubAttr->eIntfType = E_MI_DISP_INTF_LCD;
#if USE_MIPI
        eLinkType = E_MI_PNL_LINK_MIPI_DSI;
#else
        eLinkType = E_MI_PNL_LINK_TTL;
#endif
        stInputPortAttr.u16SrcWidth = inputwidth;//LOCAL_VIDEO_W;
        stInputPortAttr.u16SrcHeight = inputheight;//LOCAL_VIDEO_H;
        stInputPortAttr.stDispWin.u16X = pos.x;//LOCAL_VIDEO_X;
        stInputPortAttr.stDispWin.u16Y = pos.y;//LOCAL_VIDEO_Y;
        stInputPortAttr.stDispWin.u16Width = pos.width;//inputheight;//pos.height;
        stInputPortAttr.stDispWin.u16Height = pos.height;//inputwidth;//pos.width;

        MI_DISP_SetPubAttr(0, pstDispPubAttr);
        MI_DISP_Enable(0);
        MI_DISP_BindVideoLayer(0, 0);
        MI_DISP_EnableVideoLayer(0);
        MI_DISP_SetInputPortAttr(0, 0, &stInputPortAttr);
        MI_DISP_EnableInputPort(0, 0);
        MI_DISP_SetInputPortSyncMode(0, 0, E_MI_DISP_SYNC_MODE_FREE_RUN);

    }
#ifdef CONFIG_DEMO_ENABLE_HDMI
    else if(E_MI_DISP_INTF_HDMI == pstDispPubAttr->eIntfType)
    {
        //ST_GetHDMITimingAndDISPTiming(pstDispPubAttr->eIntfSync, &eHDMITimingType, &eDISPOutputTiming);
        eDISPOutputTiming = pstDispPubAttr->eIntfSync;
        eHDMITimingType = ST_GetHdmiTiming(eDISPOutputTiming);
        stInitParam.pCallBackArgs = NULL;
        stInitParam.pfnHdmiEventCallback = Hdmi_callback_impl;
        STCHECKRESULT(MI_HDMI_Init(&stInitParam));
        STCHECKRESULT(MI_HDMI_Open(E_MI_HDMI_ID_0));
        usleep(500*1000);
        s32Ret = ST_GetPreferredTimingFromEDID(&eHDMITimingType, &eDISPOutputTiming);
        if(MI_SUCCESS == s32Ret)
        {
            DBG_INFO("GetPreferredTiming:eHDMITimingType[%d],eDISPOutputTiming[%d]", eHDMITimingType, eDISPOutputTiming);
        }
        else
        {
            DBG_WRN("GetPreferredTimingFromEDID fail[0x%x],use set val eHDMITimingType[%d],eDISPOutputTiming[%d]\n", s32Ret, eHDMITimingType, eDISPOutputTiming);
        }
        ST_GetLayerDisplaySize(eDISPOutputTiming,&u32LayerDispWidth, &u32LayerDispHeight);
        memset(&stAttr, 0, sizeof(MI_HDMI_Attr_t));
        stAttr.stEnInfoFrame.bEnableAudInfoFrame  = FALSE;
        stAttr.stEnInfoFrame.bEnableAviInfoFrame  = FALSE;
        stAttr.stEnInfoFrame.bEnableSpdInfoFrame  = FALSE;
        stAttr.stAudioAttr.bEnableAudio = TRUE;
        stAttr.stAudioAttr.bIsMultiChannel = 0;
        stAttr.stAudioAttr.eBitDepth = E_MI_HDMI_BIT_DEPTH_16;
        stAttr.stAudioAttr.eCodeType = E_MI_HDMI_ACODE_PCM;
        stAttr.stAudioAttr.eSampleRate = E_MI_HDMI_AUDIO_SAMPLERATE_48K;
        stAttr.stVideoAttr.bEnableVideo = TRUE;
        stAttr.stVideoAttr.eColorType = E_MI_HDMI_COLOR_TYPE_RGB444;//default color type
        if((E_MI_HDMI_TIMING_4K2K_30P == eHDMITimingType) || (E_MI_HDMI_TIMING_4K2K_60P == eHDMITimingType))
        {
            stAttr.stVideoAttr.eDeepColorMode = E_MI_HDMI_DEEP_COLOR_24BIT;
            stAttr.stVideoAttr.eTimingType = eHDMITimingType;
        }
        else
        {
            stAttr.stVideoAttr.eDeepColorMode = E_MI_HDMI_DEEP_COLOR_MAX;
            stAttr.stVideoAttr.eTimingType = eHDMITimingType;
        }
        stAttr.stVideoAttr.eOutputMode = E_MI_HDMI_OUTPUT_MODE_HDMI;
        STCHECKRESULT(MI_HDMI_SetAttr(E_MI_HDMI_ID_0, &stAttr));
        STCHECKRESULT(MI_HDMI_Start(E_MI_HDMI_ID_0));
        //pstDispPubAttr->u32BgColor = YUYV_BLACK;
        pstDispPubAttr->eIntfSync = eDISPOutputTiming;
        STCHECKRESULT(MI_DISP_SetPubAttr(0, pstDispPubAttr));

        STCHECKRESULT(MI_DISP_Enable(0));
        STCHECKRESULT(MI_DISP_BindVideoLayer(0, 0));
        memset(&stLayerAttr, 0, sizeof(stLayerAttr));

        stLayerAttr.stVidLayerSize.u16Width  = u32LayerDispWidth;
        stLayerAttr.stVidLayerSize.u16Height = u32LayerDispHeight;
        stLayerAttr.ePixFormat = E_MI_SYS_PIXEL_FRAME_YUV_MST_420;
        stLayerAttr.stVidLayerDispWin.u16X      = 0;
        stLayerAttr.stVidLayerDispWin.u16Y      = 0;
        stLayerAttr.stVidLayerDispWin.u16Width  = u32LayerDispWidth;
        stLayerAttr.stVidLayerDispWin.u16Height = u32LayerDispHeight;

        STCHECKRESULT(MI_DISP_SetVideoLayerAttr(0, &stLayerAttr));
        STCHECKRESULT(MI_DISP_EnableVideoLayer(0));

        stInputPortAttr.u16SrcWidth = inputwidth;
        stInputPortAttr.u16SrcHeight = inputheight;
        stInputPortAttr.stDispWin.u16X = pos.x;
        stInputPortAttr.stDispWin.u16Y = pos.y;
        stInputPortAttr.stDispWin.u16Width = u32LayerDispWidth;
        stInputPortAttr.stDispWin.u16Height = u32LayerDispHeight;

        STCHECKRESULT(MI_DISP_SetInputPortAttr(0, 0, &stInputPortAttr));
        STCHECKRESULT(MI_DISP_EnableInputPort(0, 0));
        STCHECKRESULT(MI_DISP_SetInputPortSyncMode(0, 0, E_MI_DISP_SYNC_MODE_FREE_RUN));
    }
#endif
    if (pstDispPubAttr->eIntfType == E_MI_DISP_INTF_LCD)
    {
        MI_PANEL_Init(eLinkType);
        MI_PANEL_SetPanelParam(&stPanelParam);
        if(eLinkType == E_MI_PNL_LINK_MIPI_DSI)
        {
#if USE_MIPI
            MI_PANEL_SetMipiDsiConfig(&stMipiDsiConfig);
#endif
        }
    }
    return 0;
}
int sstar_disp_Deinit(MI_DISP_PubAttr_t *pstDispPubAttr)
{

    MI_DISP_DisableInputPort(0, 0);
    MI_DISP_DisableVideoLayer(0);
    MI_DISP_UnBindVideoLayer(0, 0);
    MI_DISP_Disable(0);

    switch(pstDispPubAttr->eIntfType)
    {
        case E_MI_DISP_INTF_HDMI:
            #ifdef CONFIG_DEMO_ENABLE_HDMI
            MI_HDMI_Stop(E_MI_HDMI_ID_0);
            MI_HDMI_Close(E_MI_HDMI_ID_0);
            MI_HDMI_DeInit();
            #endif
            break;
        case E_MI_DISP_INTF_VGA:
            break;
        case E_MI_DISP_INTF_LCD:
        default:
            MI_PANEL_DeInit();
    }

    MI_SYS_Exit();
    printf("sstar_disp_Deinit...\n");

    return 0;
}

#if defined(__cplusplus)||defined(c_plusplus)
}
#endif

