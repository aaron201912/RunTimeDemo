#include <stdio.h>
#include <stdbool.h>
#include "sstardisp.h"

int main(int argc, char **argv)
{
    const char *filename;
    bool bStopPlayer = 0;
    char c;

    if (argc < 3) {
        printf("eg: ./SsPlayer filename rotate\n");
        return -1;
    }
    
    filename    = argv[1];
    sscanf(argv[2], "%u", &g_rotate);
    printf("open file : %s, rotate : [%u]\n", filename, g_rotate);

    StartPlayVideo(filename, 0, 0, 1024, 600);

    while(!bStopPlayer)
    {
        c = getchar();
        if(c == 'q')
        {
            StopPlayVideo();
            break;
        }
    }
    return 0;
}