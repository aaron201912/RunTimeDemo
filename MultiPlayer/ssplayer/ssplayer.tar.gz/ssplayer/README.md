# ssplayer demo
    1. 目录介绍
    app:     应用main文件,初始化panel或者hdmi显示设备,调用api实现播放器功能
    ffmpeg:  包含ffmpeg头文件以及动态链接库文件,源码参考: https://github.com/aaron201912/ffmpeg/tree/master/ffmpeg-4.1.3
    player:  包含ffplayer头文件以及库文件,源码实现参考: https://github.com/aaron201912/ffmpeg/tree/master/ffplayer
    openssl: ffmpeg库依赖的openssl库文件
    libdns:  域名解析相关的库文件,播放网络流时需要用到
    wifi:    wifi使用相关,见文档说明

    2. 编译说明
    将ssplayer整个文件夹拷贝到与project同一级目录,运行下述命令:
    cd ssplayer/app;make clean;make
    也可手动设置project的路径: make ALKAID_PATH=/home/user/ssd202
    使用hdmi显示: make ENABLE_HDMI=1

    3. 运行说明
    将ffmpeg/lib, player/lib, openssl目录下的动态库拷贝到板子中(如果播放网络流libdns下的库也要拷贝到板子中),并export;将app/ssplayer执行档也拷到板子中
    ./ssplayer file test.mp4    //指定播放test.mp4文件
    ./ssplayer path /mnt/video  //应用扫描/mnt/video目录下的视频文件并播放

    4. 操作命令
    ssplayer应用支持一些简单的操作命令,应用跑起来后在shell中输入如下:
    p：暂停
    c：继续播放
    f：快进
    b：快退
    m：模式切换(单曲,单曲循环,列表循环)
    d: 获取视频总时长
    g: 获取当前播放时间点
    l: 调节亮度
    h: 调节对比度
    u: 静音
    +: 音量加
    -: 音量减
    n: 下一曲
    z: 上一曲
    q：退出


# wifi demo
    1. WIFI连接测试
    使用ssplayer/wifi下的测试demo
    按照文档描述, 编译出testWifi可执行文件
    在板子中运行./testWifi, 串口输入命令n连接热点, 通过ifconfig查看网络状态, 或者ping www.baidu.com
    wlan0     Link encap:Ethernet  HWaddr DC:29:19:06:B1:A1

    2. 配置DNS
    如果DNS无法解析, 配置如下：
    将ssplayer/libdns下的库文件拷贝到板子/customer下, 导出:
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/customer/libdns
    配置DNS服务器, 如: 
    echo "nameserver 8.8.8.8" >> /etc/resolv.conf

    3. ssplayer + wifi 播放测试
    确保网络连接OK后, 运行类似如下网络链接即可播放网络流:
    ./ssplayer file https://video.papwmhz.cn/Upload/nw/N1003.m3u8

    4. 有线联网DHCP
    ifconfig eth0 up
    ifconfig eth0 hw ether 00:70:27:00:00:01
    udhcpc -i eth0 -s /etc/init.d/udhcpc.script

