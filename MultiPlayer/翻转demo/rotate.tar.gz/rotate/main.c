#include <stdio.h>
#include <string.h>

#include "player.h"
#include "platform.h"

// 软解使用GFX旋转, H254/H265硬解使用DISP硬件旋转

int main(int argc, char **argv)
{
    const char *filename;
    bool  bStopPlayer = false;
    char c;
    int ret, width, height;

    filename    = argv[1];
    printf("try to open file: %s.\n", filename);

    sstar_sys_init();
    #ifdef SUPPORT_HDMI
    sstar_hdmi_init(E_MI_DISP_INTF_HDMI);
    width  = HDMI_MAX_W;
    height = HDMI_MAX_H;
    #else
    sstar_panel_init(E_MI_DISP_INTF_LCD);
    width  = PANEL_MAX_W;
    height = PANEL_MAX_H;
    #endif

    ret = sstar_player_open(filename, 0, 0, width, height);
    if (ret < 0) {
        goto exit;
    }
    fflush(stdout);

    while(!bStopPlayer)
    {
        fflush(stdin);
        c = getchar();
        switch (c)
        {
            case 'q': {
                sstar_player_close();
                bStopPlayer = true;
            } break;

            case 'c': {
                sstar_player_close();

                ret = sstar_player_switch();
                ret = sstar_player_open(filename, 0, 0, width, height);
                if (ret < 0) {
                    goto exit;
                }
            } break;

            default: break;
        }
        fflush(stdout);
    }

exit:
    #ifdef SUPPORT_HDMI
    sstar_hdmi_deinit(E_MI_DISP_INTF_HDMI);
    #else
    sstar_panel_deinit(E_MI_DISP_INTF_LCD);
    #endif
    sstar_sys_deinit();
    return 0;
}





