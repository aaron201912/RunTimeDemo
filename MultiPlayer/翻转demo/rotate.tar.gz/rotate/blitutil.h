#include "mi_gfx_datatype.h"
typedef struct RECT
{
    int top;
    int bottom;
    int left;
    int right;
}RECT;

#define RECTW(r) (r.right-r.left)
#define RECTH(r) (r.bottom-r.top)

typedef struct Rect
{
    int x;
    int y;
    int w;
    int h;
}Rect;

typedef struct Surface
{
    int w;
    int h;
    unsigned long long phy_addr;
    int pitch;
    MI_GFX_ColorFmt_e eGFXcolorFmt;
    int BytesPerPixel;
}Surface;


void SstarBlitCCW(Surface * pSrcSurface, Surface *pDstSurface, RECT* pRect);
void SstarBlitNormal(Surface * pSrcSurface, Surface *pDstSurface, RECT* pRect);

