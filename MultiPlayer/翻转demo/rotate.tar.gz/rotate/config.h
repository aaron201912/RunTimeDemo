/*
 * config.h
 *
 *  Created on: 2019年10月24日
 *      Author: jeffrey.wu
 */

#ifndef __SSTAR_CONFIG_H__
#define __SSTAR_CONFIG_H__

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

#define DISPLAY_1024_600    1        // 显示屏宽高属性
#define USE_MIPI            0

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* __SSTAR_CONFIG_H__ */
