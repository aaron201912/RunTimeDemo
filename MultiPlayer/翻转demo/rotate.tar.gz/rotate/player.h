#ifndef  __PLAYER_H__
#define  __PLAYER_H__

#include <stdbool.h>
#include <pthread.h>


#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libswresample/swresample.h>
#include <libavutil/frame.h>
#include <libavutil/time.h>
#include <libavutil/imgutils.h>
#include <libavutil/samplefmt.h>
#include <libavutil/avassert.h>
#include <libavutil/log.h>
#include <libavutil/file.h>

#define  HARD       0
#define  SOFT       1

typedef struct AudioParams {
    int freq;
    int channels;
    int64_t channel_layout;
    enum AVSampleFormat fmt;
    int frame_size;
    int bytes_per_sec;
} AudioParams;


typedef struct AVPlayStat {
    AVFormatContext *fmt_ctx;
    AVInputFormat *iformat;
    AVCodecContext *video_ctx;
    AVCodecContext *audio_ctx;
    struct SwrContext *swr_ctx;
    struct SwsContext *img_ctx;

    AVFrame *frm_yuv;
    unsigned long long phy_addr;
    uint8_t *vir_addr;
    int buf_size;
    int src_width, src_height;
    int dst_width, dst_height;
    int posx ,posy;
    int out_width, out_height;
    int in_width, in_height;

    AudioParams audio_src;
    AudioParams audio_tgt;
    uint8_t *audio_buf;
    uint8_t *audio_buf1;
    unsigned int audio_buf1_size;

    int  seekflag;
    int  max_frame_duration;
    int  decoder;
    int  mode;
    bool exit;
    pthread_t playtid;
}AVPlayStat;

typedef struct AVBufferData {
    uint8_t *ptr;
    size_t size; ///< size left in the buffer
}AVBufferData;


int sstar_player_open(char *url, int x, int y, int width, int height);
int sstar_player_close(void);
int sstar_player_switch(void);


#endif
