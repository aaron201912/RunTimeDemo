#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "player.h"
#include "platform.h"
#include "blitutil.h"

#include "mi_vdec_extra.h"

static int st_index[AVMEDIA_TYPE_NB];
static AVPlayStat *isplay = NULL;
static int rotate_paramter = E_MI_DISP_ROTATE_NONE;

FILE *fp;

static int video_putbuf_back(AVFrame *frame)
{
    if (frame->opaque)
    {
        SS_Vdec_BufInfo *stVdecBuf = (SS_Vdec_BufInfo *)frame->opaque;
        //av_log(NULL, AV_LOG_INFO, "frame->opaque addr : %p\n", frame->opaque);
        int ret = MI_SYS_ChnOutputPortPutBuf(stVdecBuf->stVdecHandle);
        if (MI_SUCCESS != ret)
            av_log(NULL, AV_LOG_ERROR, "MI_SYS_ChnOutputPortPutBuf Failed!\n");
        return ret;
    }
    return -1;
}

static void sstar_video_rotate(AVPlayStat *is, MI_PHY yAddr, MI_PHY uvAddr)
{
    Surface srcY, dstY;
    Surface srcUV, dstUV;
    RECT r;
    srcY.eGFXcolorFmt   = E_MI_GFX_FMT_I8;
    srcY.h              = is->video_ctx->height;
    srcY.phy_addr       = is->phy_addr;
    srcY.pitch          = is->video_ctx->width;
    srcY.w              = is->video_ctx->width;
    srcY.BytesPerPixel  = 1;

    dstY.eGFXcolorFmt   = E_MI_GFX_FMT_I8;
    dstY.h              = srcY.w;
    dstY.phy_addr       = yAddr;
    dstY.pitch          = ALIGN_UP(srcY.h, 16);
    dstY.w              = srcY.h;
    dstY.BytesPerPixel  = 1;
    r.left   = 0;
    r.top    = 0;
    r.bottom = srcY.h;
    r.right  = srcY.w;
    SstarBlitCCW(&srcY, &dstY, &r);

    srcUV.eGFXcolorFmt  = E_MI_GFX_FMT_ARGB4444;
    srcUV.h             = is->video_ctx->height / 2;
    srcUV.phy_addr      = is->phy_addr + is->video_ctx->width * is->video_ctx->height;
    srcUV.pitch         = is->video_ctx->width;
    srcUV.w             = is->video_ctx->width / 2;
    srcUV.BytesPerPixel = 2;

    dstUV.eGFXcolorFmt  = E_MI_GFX_FMT_ARGB4444;
    dstUV.h             = srcUV.w;
    dstUV.phy_addr      = uvAddr;
    dstUV.pitch         = ALIGN_UP(srcY.h, 16);
    dstUV.w             = srcUV.h;
    dstUV.BytesPerPixel = 2;
    r.left   = 0;
    r.top    = 0;
    r.bottom = srcUV.h;
    r.right  = srcUV.w;
    SstarBlitCCW(&srcUV, &dstUV, &r);
}

struct timeval time_start, time_end;
int64_t time0, time1;

static int video_load_picture(AVPlayStat *is, AVFrame *frame)
{
    if (is->decoder == SOFT) {
        MI_SYS_ChnPort_t  stInputChnPort;
        memset(&stInputChnPort, 0, sizeof(MI_SYS_ChnPort_t));
        stInputChnPort.eModId                    = E_MI_MODULE_ID_DIVP;
        stInputChnPort.u32ChnId                  = 0;
        stInputChnPort.u32DevId                  = 0;
        stInputChnPort.u32PortId                 = 0;

        //gettimeofday(&time_start, NULL);
        // YUV格式统一转换成NV12
        sws_scale(is->img_ctx,                   // sws context
             (const uint8_t *const *)frame->data,// src slice
             frame->linesize,                    // src stride
             0,                                  // src slice y
             is->video_ctx->height,              // src slice height
             is->frm_yuv->data,                  // dst planes
             is->frm_yuv->linesize               // dst strides
             );
        //gettimeofday(&time_end, NULL);
        //time0 = ((int64_t)time_end.tv_sec * 1000000 + time_end.tv_usec) - ((int64_t)time_start.tv_sec * 1000000 + time_start.tv_usec);

        MI_SYS_BufConf_t stBufConf;
        MI_SYS_BufInfo_t stBufInfo;
        MI_SYS_BUF_HANDLE bufHandle;
        memset(&stBufConf, 0, sizeof(MI_SYS_BufConf_t));
        stBufConf.eBufType              = E_MI_SYS_BUFDATA_FRAME;
        stBufConf.stFrameCfg.eFormat    = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
        if (is->mode != E_MI_DISP_ROTATE_NONE) {
            stBufConf.stFrameCfg.u16Height  = is->frm_yuv->width;
            stBufConf.stFrameCfg.u16Width   = is->frm_yuv->height;
        } else {
            stBufConf.stFrameCfg.u16Height  = is->frm_yuv->height;
            stBufConf.stFrameCfg.u16Width   = is->frm_yuv->width;
        }
        stBufConf.u32Flags              = MI_SYS_MAP_VA;
        stBufConf.stFrameCfg.stFrameBufExtraConf.u16BufHAlignment = 16;
        //printf("divp input width and height : [%d %d]\n", stBufConf.stFrameCfg.u16Width, stBufConf.stFrameCfg.u16Height);

        if (MI_SUCCESS == MI_SYS_ChnInputPortGetBuf(&stInputChnPort, &stBufConf, &stBufInfo, &bufHandle, 0))
        {
            // GFX旋转图片
            if (is->mode != E_MI_DISP_ROTATE_NONE) {
                //gettimeofday(&time_start, NULL);
                sstar_video_rotate(is, stBufInfo.stFrameData.phyAddr[0], stBufInfo.stFrameData.phyAddr[1]);
                //gettimeofday(&time_end, NULL);
            } else {
                //stBufInfo.stFrameData.eCompressMode = E_MI_SYS_COMPRESS_MODE_NONE;
                //stBufInfo.stFrameData.eFieldType    = E_MI_SYS_FIELDTYPE_NONE;
                //stBufInfo.stFrameData.eTileMode     = E_MI_SYS_FRAME_TILE_MODE_NONE;
                //stBufInfo.bEndOfStream              = FALSE;
                int length = is->frm_yuv->width * is->frm_yuv->height;
                for (int index = 0; index < stBufInfo.stFrameData.u16Height; index ++)
                {
                    MI_SYS_MemcpyPa(stBufInfo.stFrameData.phyAddr[0] + index * stBufInfo.stFrameData.u32Stride[0], 
                                    is->phy_addr + index * frame->width, frame->width);
                }
                for (int index = 0; index < stBufInfo.stFrameData.u16Height / 2; index ++)
                {
                    MI_SYS_MemcpyPa(stBufInfo.stFrameData.phyAddr[1] + index * stBufInfo.stFrameData.u32Stride[1], 
                                    is->phy_addr + length + index * frame->width, frame->width);
                }
            }

            MI_SYS_ChnInputPortPutBuf(bufHandle, &stBufInfo, FALSE);
        }

        //time1 = ((int64_t)time_end.tv_sec * 1000000 + time_end.tv_usec) - ((int64_t)time_start.tv_sec * 1000000 + time_start.tv_usec);
        //printf("time of sws_scale : %lldus, time of rotate : %lldus\n", time0, time1);
    }
    else if (is->decoder == HARD) {
        MI_SYS_ChnPort_t  stInputChnPort;
        memset(&stInputChnPort, 0, sizeof(MI_SYS_ChnPort_t));
        stInputChnPort.eModId                    = E_MI_MODULE_ID_DISP;
        stInputChnPort.u32ChnId                  = 0;
        stInputChnPort.u32DevId                  = 0;
        stInputChnPort.u32PortId                 = 0;

        av_assert0(frame->opaque);
        SS_Vdec_BufInfo *stVdecBuf = (SS_Vdec_BufInfo *)frame->opaque; 

        if (MI_SUCCESS != MI_SYS_ChnPortInjectBuf(stVdecBuf->stVdecHandle, &stInputChnPort))
            av_log(NULL, AV_LOG_ERROR, "MI_SYS_ChnPortInjectBuf failed!\n");

        av_freep(&frame->opaque);
    }

    return 0;
}

static int video_display_init(void)
{
    if (!isplay) {
        return -1;
    }

    MI_DISP_InputPortAttr_t stInputPortAttr;
    MI_DISP_RotateConfig_t stRotateConfig;

    MI_DISP_DisableInputPort(0, 0);
    memset(&stInputPortAttr, 0, sizeof(MI_DISP_InputPortAttr_t));
    stInputPortAttr.u16SrcWidth         = ALIGN_BACK(isplay->src_width , 32);
    stInputPortAttr.u16SrcHeight        = ALIGN_BACK(isplay->src_height, 32);
    stInputPortAttr.stDispWin.u16X      = isplay->posx;
    stInputPortAttr.stDispWin.u16Y      = isplay->posy;
    stInputPortAttr.stDispWin.u16Width  = isplay->out_width;
    stInputPortAttr.stDispWin.u16Height = isplay->out_height;

    MI_DISP_SetInputPortAttr(0, 0, &stInputPortAttr);
    MI_DISP_EnableInputPort(0, 0);
    MI_DISP_SetInputPortSyncMode(0, 0, E_MI_DISP_SYNC_MODE_FREE_RUN);

    if (isplay->decoder == SOFT)
    {
        MI_DIVP_OutputPortAttr_t stDivpOutAttr;
        MI_DIVP_ChnAttr_t stDivpChnAttr;
        MI_SYS_ChnPort_t stDivpChnPort;
        MI_SYS_ChnPort_t stDispChnPort;
        MI_GFX_Open();

        memset(&stDivpChnAttr, 0, sizeof(MI_DIVP_ChnAttr_t));
        stDivpChnAttr.bHorMirror            = FALSE;
        stDivpChnAttr.bVerMirror            = FALSE;
        stDivpChnAttr.eDiType               = E_MI_DIVP_DI_TYPE_OFF;
        stDivpChnAttr.eRotateType           = E_MI_SYS_ROTATE_NONE;
        stDivpChnAttr.eTnrLevel             = E_MI_DIVP_TNR_LEVEL_OFF;
        stDivpChnAttr.stCropRect.u16X       = 0;
        stDivpChnAttr.stCropRect.u16Y       = 0;
        stDivpChnAttr.stCropRect.u16Width   = 0;
        stDivpChnAttr.stCropRect.u16Height  = 0;
        stDivpChnAttr.u32MaxWidth           = 1920;
        stDivpChnAttr.u32MaxHeight          = 1080;

        MI_DIVP_CreateChn(0, &stDivpChnAttr);
        MI_DIVP_SetChnAttr(0, &stDivpChnAttr);

        memset(&stDivpOutAttr, 0, sizeof(MI_DIVP_OutputPortAttr_t));
        stDivpOutAttr.eCompMode             = E_MI_SYS_COMPRESS_MODE_NONE;
        stDivpOutAttr.ePixelFormat          = E_MI_SYS_PIXEL_FRAME_YUV_SEMIPLANAR_420;
        stDivpOutAttr.u32Width              = ALIGN_BACK(isplay->src_width , 32);
        stDivpOutAttr.u32Height             = ALIGN_BACK(isplay->src_height, 32);
        MI_DIVP_SetOutputPortAttr(0, &stDivpOutAttr);
        MI_DIVP_StartChn(0);
        memset(&stDispChnPort, 0, sizeof(MI_SYS_ChnPort_t));
        stDispChnPort.eModId                = E_MI_MODULE_ID_DISP;
        stDispChnPort.u32DevId              = 0;
        stDispChnPort.u32ChnId              = 0;
        stDispChnPort.u32PortId             = 0;

        memset(&stDivpChnPort, 0, sizeof(MI_SYS_ChnPort_t));
        stDivpChnPort.eModId                = E_MI_MODULE_ID_DIVP;
        stDivpChnPort.u32DevId              = 0;
        stDivpChnPort.u32ChnId              = 0;
        stDivpChnPort.u32PortId             = 0;

        MI_SYS_SetChnOutputPortDepth(&stDivpChnPort, 0, 3);
        MI_SYS_BindChnPort(&stDivpChnPort, &stDispChnPort, 30, 30);

        memset(&stRotateConfig, 0, sizeof(MI_DISP_RotateConfig_t));
        stRotateConfig.eRotateMode = E_MI_DISP_ROTATE_NONE;
    }else {
        memset(&stRotateConfig, 0, sizeof(MI_DISP_RotateConfig_t));
        // 硬解需要设置DISP属性开启旋转
        stRotateConfig.eRotateMode = isplay->mode;
    }

    MI_DISP_SetVideoLayerRotateMode(0, &stRotateConfig);

    return 0;
}

static int video_display_deinit(void)
{
    if (isplay->decoder == SOFT)
    {
        MI_SYS_ChnPort_t stDispChnPort;
        MI_SYS_ChnPort_t stDivpChnPort;

        memset(&stDispChnPort, 0, sizeof(MI_SYS_ChnPort_t));
        stDispChnPort.eModId                = E_MI_MODULE_ID_DISP;
        stDispChnPort.u32DevId              = 0;
        stDispChnPort.u32ChnId              = 0;
        stDispChnPort.u32PortId             = 0;

        memset(&stDivpChnPort, 0, sizeof(MI_SYS_ChnPort_t));
        stDivpChnPort.eModId                = E_MI_MODULE_ID_DIVP;
        stDivpChnPort.u32DevId              = 0;
        stDivpChnPort.u32ChnId              = 0;
        stDivpChnPort.u32PortId             = 0;

        MI_SYS_UnBindChnPort(&stDivpChnPort, &stDispChnPort);

        MI_DIVP_StopChn(0);
        MI_DIVP_DestroyChn(0);
        MI_GFX_Close();
    }

    return 0;
}


static int audio_send_data(uint8_t *data, int length)
{
    int data_idx = 0, data_len = length;
    MI_AUDIO_Frame_t stAoSendFrame;
    MI_S32 s32RetSendStatus = 0;
    MI_AO_CHN AoChn = 0;
    do {
        if (data_len <= MI_AUDIO_MAX_DATA_SIZE)
        {
            stAoSendFrame.u32Len = data_len;
        }
        else
        {
            stAoSendFrame.u32Len = MI_AUDIO_MAX_DATA_SIZE; 
        }
        stAoSendFrame.apVirAddr[0] = &data[data_idx];
        stAoSendFrame.apVirAddr[1] = NULL;  

        data_len -= MI_AUDIO_MAX_DATA_SIZE;
        data_idx += MI_AUDIO_MAX_DATA_SIZE;

        do{
            s32RetSendStatus = MI_AO_SendFrame(AO_DEV_ID, AoChn, &stAoSendFrame, 128);
        }while(s32RetSendStatus == MI_AO_ERR_NOBUF);

        if(s32RetSendStatus != MI_SUCCESS)
        {
            av_log(NULL, AV_LOG_ERROR, "[Warning]: MI_AO_SendFrame fail.\n");
        }
    }while(data_len > 0);

    return s32RetSendStatus;
}

static int audio_decode_frame(AVPlayStat *is, AVFrame *frame)
{
    int data_size, resampled_data_size;
    int64_t dec_channel_layout;
    int wanted_nb_samples;

    data_size = av_samples_get_buffer_size(NULL, frame->channels,
                                           frame->nb_samples,
                                           frame->format, 1);

    dec_channel_layout =
        (frame->channel_layout && frame->channels == av_get_channel_layout_nb_channels(frame->channel_layout)) ?
         frame->channel_layout : av_get_default_channel_layout(frame->channels);
    wanted_nb_samples = frame->nb_samples;

    if (frame->format        != is->audio_src.fmt            ||
        dec_channel_layout   != is->audio_src.channel_layout ||
        frame->sample_rate   != is->audio_src.freq           ||
        (wanted_nb_samples   != frame->nb_samples && !is->swr_ctx)) {
        swr_free(&is->swr_ctx);
        is->swr_ctx = swr_alloc_set_opts(NULL,
                                         is->audio_tgt.channel_layout, is->audio_tgt.fmt, is->audio_tgt.freq,
                                         dec_channel_layout, frame->format, frame->sample_rate,
                                         0, NULL);
        if (!is->swr_ctx || swr_init(is->swr_ctx) < 0) {
            av_log(NULL, AV_LOG_ERROR,
                   "Cannot create sample rate converter for conversion of %d Hz %s %d channels to %d Hz %s %d channels!\n",
                    frame->sample_rate, av_get_sample_fmt_name(frame->format), frame->channels,
                    is->audio_tgt.freq, av_get_sample_fmt_name(is->audio_tgt.fmt), is->audio_tgt.channels);
            swr_free(&is->swr_ctx);
            return -1;
        }
        is->audio_src.channel_layout = dec_channel_layout;
        is->audio_src.channels       = frame->channels;
        is->audio_src.freq           = frame->sample_rate;
        is->audio_src.fmt            = frame->format;
    }

    if (is->swr_ctx) {
        const uint8_t **in = (const uint8_t **)frame->extended_data;
        uint8_t **out = &is->audio_buf1;
        int out_count = (int64_t)wanted_nb_samples * is->audio_tgt.freq / frame->sample_rate + 256;
        int out_size  = av_samples_get_buffer_size(NULL, is->audio_tgt.channels, out_count, is->audio_tgt.fmt, 0);
        int len2;
        if (out_size < 0) {
            av_log(NULL, AV_LOG_ERROR, "av_samples_get_buffer_size() failed\n");
            return -1;
        }
        if (wanted_nb_samples != frame->nb_samples) {
            if (swr_set_compensation(is->swr_ctx, (wanted_nb_samples - frame->nb_samples) * is->audio_tgt.freq / frame->sample_rate,
                                        wanted_nb_samples * is->audio_tgt.freq / frame->sample_rate) < 0) {
                av_log(NULL, AV_LOG_ERROR, "swr_set_compensation() failed\n");
                return -1;
            }
        }
        av_fast_malloc(&is->audio_buf1, &is->audio_buf1_size, out_size);
        if (!is->audio_buf1)
            return AVERROR(ENOMEM);
        len2 = swr_convert(is->swr_ctx, out, out_count, in, frame->nb_samples);
        if (len2 < 0) {
            av_log(NULL, AV_LOG_ERROR, "swr_convert() failed\n");
            return -1;
        }
        if (len2 == out_count) {
            av_log(NULL, AV_LOG_WARNING, "audio buffer is probably too small\n");
            if (swr_init(is->swr_ctx) < 0)
                swr_free(&is->swr_ctx);
        }
        is->audio_buf = is->audio_buf1;
        resampled_data_size = len2 * is->audio_tgt.channels * av_get_bytes_per_sample(is->audio_tgt.fmt);
    } else {
        is->audio_buf = frame->data[0];
        resampled_data_size = data_size;
    }

    return resampled_data_size;
}

static void *sstar_player_thread(void *arg)
{
    AVPlayStat *is = (AVPlayStat *)arg;
    AVPacket *packet = av_packet_alloc();
    AVFrame *frame = av_frame_alloc();
    AVRational tb = is->fmt_ctx->streams[st_index[AVMEDIA_TYPE_VIDEO]]->time_base;
    int ret;

    printf("get int sstar_player_thread\n");
play:
    while (av_read_frame(is->fmt_ctx, packet) >= 0 && !is->exit) {
        if(packet->stream_index == st_index[AVMEDIA_TYPE_AUDIO]) 
        {
            ret = avcodec_send_packet(is->audio_ctx, packet);
            if(ret < 0) {
                av_log(NULL, AV_LOG_ERROR, "avcodec_send_packet fail!\n");
                continue;
            }

            ret = avcodec_receive_frame(is->audio_ctx, frame);
            if (ret < 0 && ret != AVERROR(EAGAIN)) {
                av_log(NULL, AV_LOG_ERROR, "avcodec_receive_frame fail\n");
                goto fail;
            }
            if (ret >= 0) {
                ret = audio_decode_frame(is, frame);
                if (ret < 0) {
                    av_log(NULL, AV_LOG_ERROR, "audio_decode_frame fail\n");
                    continue;
                } else {
                    //av_log(NULL, AV_LOG_INFO, "audio valid data size: %d.\n", ret);
                    audio_send_data(is->audio_buf, ret);
                }
            }
        }

        if(packet->stream_index == st_index[AVMEDIA_TYPE_VIDEO])
        {
            ret = avcodec_send_packet(is->video_ctx, packet);
            if(ret < 0) {
                av_log(NULL, AV_LOG_ERROR, "avcodec_send_packet fail!\n");
                continue;
            }

            ret = avcodec_receive_frame(is->video_ctx, frame);
            if (ret < 0 && ret != AVERROR(EAGAIN))
            {
                av_log(NULL, AV_LOG_ERROR, "avcodec_receive_frame fail\n");
                goto fail;
            }
            if (ret >= 0) {
                #if 0
                    //av_log(NULL, AV_LOG_INFO, "video get vdec frame done.\n");
                    av_log(NULL, AV_LOG_INFO, "frame pts value : %.6f.\n", (double)frame->pts * av_q2d(tb));
                    //SS_Vdec_BufInfo *stVdecBuf = (SS_Vdec_BufInfo *)frame->opaque; 
                    int length = frame->width * frame->height;
                    //fwrite(stVdecBuf->stVdecBufInfo.stFrameData.pVirAddr[0], length, 1, fp);
                    //fwrite(stVdecBuf->stVdecBufInfo.stFrameData.pVirAddr[1], length / 2, 1, fp); 
                    //video_putbuf_back(frame);
                    //av_freep(&frame->opaque);
                    fwrite(frame->data[0], length, 1, fp);
                    fwrite(frame->data[1], length / 2, 1, fp); 
                #else
                //av_log(NULL, AV_LOG_INFO, "video get vdec frame done.\n");
                //av_log(NULL, AV_LOG_TRACE, "frame pts value : %.6f.\n", (double)frame->pts * av_q2d(tb));
                video_load_picture(is, frame);
                #endif
            }
            av_usleep(30 * 1000);
        }

        av_frame_unref(frame);
        av_packet_unref(packet);
    }

    is->seekflag &= ~AVSEEK_FLAG_BYTE;
    avformat_seek_file(is->fmt_ctx, -1, INT64_MIN, is->fmt_ctx->start_time, INT64_MAX, is->seekflag);
    if(!is->exit)
        goto play;
fail:
    /*if (frame->opaque) {
        video_putbuf_back(frame);
        av_freep(&frame->opaque);
    }*/

    av_frame_free(&frame);
    av_packet_free(&packet);
    if (is->swr_ctx) {
        swr_free(&is->swr_ctx);
    }
    if (is->audio_buf) {
        av_freep(&is->audio_buf);
    }
    printf("### sstar_player_thread exit ###\n");
    return NULL;
}

int sstar_player_switch(void)
{
    if (rotate_paramter != E_MI_DISP_ROTATE_NONE) {
        rotate_paramter = E_MI_DISP_ROTATE_NONE;
    } else {
        rotate_paramter = E_MI_DISP_ROTATE_270;
    }
    av_log(NULL, AV_LOG_WARNING, "switch to display mode[%d]\n", rotate_paramter);

    return rotate_paramter;
}

int sstar_player_open(char *url, int x, int y, int width, int height)
{
    int err, ret;
    int show_status = 1;

    //fp = fopen("/mnt/output.yuv", "a+");

    isplay = (AVPlayStat *)av_mallocz(sizeof(AVPlayStat));
    if (!isplay) {
        av_log(NULL, AV_LOG_FATAL, "av_mallocz for player failed.\n");
        return AVERROR(ENOMEM);
    }
    memset(isplay, 0, sizeof(AVPlayStat));
    for (int i = 0; i < AVMEDIA_TYPE_NB; i ++) {
        st_index[i] = -1;
    }

    isplay->mode = rotate_paramter;
    isplay->posx = x;
    isplay->posy = y;
    isplay->in_width  = width;
    isplay->in_height = height;

    isplay->fmt_ctx = avformat_alloc_context();
    if (!isplay->fmt_ctx) {
        av_log(NULL, AV_LOG_FATAL, "could not allocate context.\n");
        ret = AVERROR(ENOMEM);
        goto fail;
    }

    //isplay->fmt_ctx->probesize = 100 * 1024;
    //isplay->fmt_ctx->max_analyze_duration = 7 * AV_TIME_BASE;
    //isplay->fmt_ctx->flags |= AVFMT_FLAG_NOBUFFER; 
    err = avformat_open_input(&isplay->fmt_ctx, url, isplay->iformat, NULL);
    if (err < 0) {
        av_log(NULL, AV_LOG_FATAL, "avformat_open_input failed.\n"); 
        ret = -1;
        goto fail;
    }

    err = avformat_find_stream_info(isplay->fmt_ctx, NULL);
    if (err < 0) {
        av_log(NULL, AV_LOG_FATAL, "avformat_find_stream_info failed.\n"); 
        ret = -1;
        goto fail;
    }

    for (int i = 0; i < isplay->fmt_ctx->nb_streams; i ++) {
        if (isplay->fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO) {
            st_index[AVMEDIA_TYPE_AUDIO] = i;
        } else if (isplay->fmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            st_index[AVMEDIA_TYPE_VIDEO] = i;
        }
    }

    av_log(NULL, AV_LOG_INFO, "video index : %d, audio index : %d\n", st_index[AVMEDIA_TYPE_VIDEO], st_index[AVMEDIA_TYPE_AUDIO]);

    isplay->max_frame_duration = (isplay->fmt_ctx->iformat->flags & AVFMT_TS_DISCONT) ? 10.0 : 3600.0;

    if (isplay->fmt_ctx->pb)
        isplay->fmt_ctx->pb->eof_reached = 0; // FIXME hack, ffplay maybe should not use avio_feof() to test for the end

    if (show_status)
        av_dump_format(isplay->fmt_ctx, 0, url, 0);

    if (st_index[AVMEDIA_TYPE_VIDEO] >= 0) {
        AVStream *st = isplay->fmt_ctx->streams[st_index[AVMEDIA_TYPE_VIDEO]];
        AVCodecParameters *codecpar = st->codecpar;
        AVCodec *vcodec;

        isplay->video_ctx = avcodec_alloc_context3(NULL);
        if (!isplay->video_ctx) {
            av_log(NULL, AV_LOG_ERROR, "video avcodec_alloc_context3 failed.\n");
            ret = AVERROR(ENOMEM);
            goto fail;
        }

        err = avcodec_parameters_to_context(isplay->video_ctx, codecpar);
        if (err < 0) {
            av_log(NULL, AV_LOG_ERROR, "video avcodec_parameters_to_context failed.\n");
            ret = -1;
            goto fail;
        }
        isplay->video_ctx->pkt_timebase = isplay->fmt_ctx->streams[st_index[AVMEDIA_TYPE_VIDEO]]->time_base;

        switch(isplay->video_ctx->codec_id) {
            case AV_CODEC_ID_H264 :
            {
                vcodec = avcodec_find_decoder_by_name("ssh264");
                isplay->decoder = HARD;
            }
            break;

            case AV_CODEC_ID_HEVC :
            {
                vcodec = avcodec_find_decoder_by_name("sshevc");
                isplay->decoder = HARD;
            }
            break;

            default : 
                vcodec = avcodec_find_decoder(isplay->video_ctx->codec_id); 
                isplay->decoder = SOFT;
            break;
        }
        if (vcodec == NULL) {
            av_log(NULL, AV_LOG_ERROR, "cannot find a video codec.\n");
            ret = -1;
            goto fail;
        }
        av_log(NULL, AV_LOG_INFO, "open video codec: %s\n", vcodec->name);

        isplay->out_width  = isplay->in_width;
        isplay->out_height = isplay->in_height;

        if (isplay->decoder == HARD) {
            if (isplay->mode != E_MI_DISP_ROTATE_NONE) {
                isplay->video_ctx->flags  = FFMIN(ALIGN_BACK(isplay->out_height, 32), ALIGN_BACK(isplay->video_ctx->width , 32));
                isplay->video_ctx->flags2 = FFMIN(ALIGN_BACK(isplay->out_width , 32), ALIGN_BACK(isplay->video_ctx->height, 32));
                isplay->src_width  = FFMIN(isplay->out_height, isplay->video_ctx->width);
                isplay->src_height = FFMIN(isplay->out_width , isplay->video_ctx->height);
                // 如果开启旋转使用TileMode
                isplay->video_ctx->flags |= (1 << 17);
            } else {
                isplay->video_ctx->flags  = FFMIN(ALIGN_BACK(isplay->out_width , 32), ALIGN_BACK(isplay->video_ctx->width , 32));
                isplay->video_ctx->flags2 = FFMIN(ALIGN_BACK(isplay->out_height, 32), ALIGN_BACK(isplay->video_ctx->height, 32));
                isplay->src_width  = FFMIN(isplay->out_width , isplay->video_ctx->width);
                isplay->src_height = FFMIN(isplay->out_height, isplay->video_ctx->height);
            }
            av_log(NULL, AV_LOG_INFO, "vdec output w/h = [%d %d], display w/h = [%d %d], \n", (isplay->video_ctx->flags & 0xFFFF), isplay->video_ctx->flags2, isplay->out_width, isplay->out_height);
        }
        // 根据解码器类型选择流程
        else if (isplay->decoder == SOFT)
        {
            int dst_width, dst_height;
            const AVPixFmtDescriptor *desc;

            if (isplay->mode != E_MI_DISP_ROTATE_NONE) {
                isplay->src_width  = FFMIN(isplay->out_width , isplay->video_ctx->height);
                isplay->src_height = FFMIN(isplay->out_height, isplay->video_ctx->width);
            } else {
                isplay->src_width  = FFMIN(isplay->out_width , isplay->video_ctx->width);
                isplay->src_height = FFMIN(isplay->out_height, isplay->video_ctx->height);
            }
            av_log(NULL, AV_LOG_INFO, "scaler w/h = [%d %d], display w/h = [%d %d], \n", isplay->src_width, isplay->src_height, isplay->out_width, isplay->out_height);

            if (isplay->video_ctx->width > isplay->video_ctx->height) {
                dst_width  = FFMIN(isplay->video_ctx->width , 1920);
                dst_height = FFMIN(isplay->video_ctx->height, 1080);
            } else {
                dst_width  = FFMIN(isplay->video_ctx->width , 1080);
                dst_height = FFMIN(isplay->video_ctx->height, 1920);
            }

            isplay->frm_yuv = av_frame_alloc();
            if (isplay->frm_yuv == NULL)
            {
                av_log(NULL, AV_LOG_ERROR, "[%s %d]av_frame_alloc failed!\n", __FUNCTION__, __LINE__);
                return -1;
            }

            // 为AVFrame.*data[]手工分配缓冲区，用于存储sws_scale()中目的帧视频数据
            isplay->buf_size = av_image_get_buffer_size(AV_PIX_FMT_NV12, 
                                                        dst_width,
                                                        dst_height,
                                                        1
                                                        );
            av_log(NULL, AV_LOG_INFO, "alloc size: %d,width: %d,height: %d\n", isplay->buf_size, dst_width, dst_height);

            // buffer将作为p_frm_yuv的视频数据缓冲区
            ret = MI_SYS_MMA_Alloc((MI_U8 *)"#rotat420", isplay->buf_size, &isplay->phy_addr);
            if (ret != MI_SUCCESS) {
                av_log(NULL, AV_LOG_ERROR, "MI_SYS_MMA_Alloc Falied!\n");
                return -1;
            }

            ret = MI_SYS_Mmap(isplay->phy_addr, isplay->buf_size, (void **)&isplay->vir_addr, FALSE);
            if (ret != MI_SUCCESS) {
                av_log(NULL, AV_LOG_ERROR, "MI_SYS_Mmap Falied!\n");
                return -1;
            }

            // 使用给定参数设定p_frm_yuv->data和p_frm_yuv->linesize
            isplay->frm_yuv->width  = dst_width;
            isplay->frm_yuv->height = dst_height;
            ret = av_image_fill_arrays(isplay->frm_yuv->data,     // dst data[]
                                       isplay->frm_yuv->linesize, // dst linesize[]
                                       isplay->vir_addr,          // src buffer
                                       AV_PIX_FMT_NV12,           // pixel format
                                       dst_width,
                                       dst_height,
                                       1                          // align
                                       );
            if (ret < 0)
            {
                av_log(NULL, AV_LOG_ERROR, "av_image_fill_arrays() failed %d\n", ret);
                return -1;;
            }

            desc = av_pix_fmt_desc_get(isplay->video_ctx->pix_fmt);
            av_log(NULL, AV_LOG_INFO, "video prefix format : %s.\n", desc->name);

            isplay->img_ctx = sws_getContext(isplay->video_ctx->width,   // src width
                                             isplay->video_ctx->height,  // src height
                                             isplay->video_ctx->pix_fmt, // src format
                                             dst_width,
                                             dst_height,
                                             AV_PIX_FMT_NV12,            // dst format
                                             SWS_POINT,                  // flags
                                             NULL,                       // src filter
                                             NULL,                       // dst filter
                                             NULL                        // param
                                             );
            if (isplay->img_ctx == NULL)
            {
                av_log(NULL, AV_LOG_ERROR, "sws_getContext() failed\n");
                return -1;
            }
            //av_log(NULL, AV_LOG_WARNING, "virtual addr : %p, frame data addr : %p\n", isplay->vir_addr, isplay->frm_yuv->data);
        }

        err = avcodec_open2(isplay->video_ctx, vcodec, NULL);
        if (err < 0) {
            av_log(NULL, AV_LOG_ERROR, "video avcodec_open2 failed.\n");
            ret = -1;
            goto fail;
        }

        isplay->fmt_ctx->streams[st_index[AVMEDIA_TYPE_VIDEO]]->discard = AVDISCARD_DEFAULT;

        video_display_init();

        isplay->video_ctx->debug  = true;
    }   

    if (st_index[AVMEDIA_TYPE_AUDIO] >= 0) {
        AVStream *st = isplay->fmt_ctx->streams[st_index[AVMEDIA_TYPE_AUDIO]];
        AVCodecParameters *codecpar = st->codecpar;
        AVCodec *acodec;

        sstar_audio_init();

        isplay->audio_ctx = avcodec_alloc_context3(NULL);
        if (!isplay->audio_ctx) {
            av_log(NULL, AV_LOG_ERROR, "audio avcodec_alloc_context3 failed.\n");
            ret = AVERROR(ENOMEM);
            goto fail;
        }

        err = avcodec_parameters_to_context(isplay->audio_ctx, codecpar);
        if (err < 0) {
            av_log(NULL, AV_LOG_ERROR, "audio avcodec_parameters_to_context failed.\n");
            ret = -1;
            goto fail;
        }

        acodec = avcodec_find_decoder(isplay->audio_ctx->codec_id);
        if (acodec == NULL) {
            av_log(NULL, AV_LOG_ERROR, "cannot find a audio codec.\n");
            ret = -1;
            goto fail;
        }
        av_log(NULL, AV_LOG_INFO, "open audio codec: %s\n", acodec->name);

        err = avcodec_open2(isplay->audio_ctx, acodec, NULL);
        if (err < 0) {
            av_log(NULL, AV_LOG_ERROR, "audio avcodec_open2 failed.\n");
            ret = -1;
            goto fail;
        }
        isplay->fmt_ctx->streams[st_index[AVMEDIA_TYPE_AUDIO]]->discard = AVDISCARD_DEFAULT;

        isplay->audio_tgt.fmt            = AV_SAMPLE_FMT_S16;
        isplay->audio_tgt.freq           = 48000;
        isplay->audio_tgt.channel_layout = AV_CH_LAYOUT_MONO;
        
        isplay->audio_tgt.channels       = av_get_channel_layout_nb_channels(isplay->audio_tgt.channel_layout);
        isplay->audio_tgt.frame_size     = av_samples_get_buffer_size(NULL, isplay->audio_tgt.channels, 1, isplay->audio_tgt.fmt, 1);
        isplay->audio_tgt.bytes_per_sec  = av_samples_get_buffer_size(NULL, isplay->audio_tgt.channels, isplay->audio_tgt.freq, isplay->audio_tgt.fmt, 1);
    }

    isplay->exit = false;
    pthread_create(&isplay->playtid, NULL, sstar_player_thread, (void *)isplay);
    return 0;
fail:
    if (isplay->video_ctx)
        avcodec_free_context(&isplay->video_ctx);
    if (isplay->audio_ctx)
        avcodec_free_context(&isplay->audio_ctx);
    if (isplay->img_ctx)
        sws_freeContext(isplay->img_ctx);
    if (isplay->frm_yuv)
        av_frame_free(&isplay->frm_yuv);
    if (isplay->fmt_ctx)
        avformat_close_input(&isplay->fmt_ctx);
    if (isplay)
        av_freep(&isplay);
    return ret;
}

int sstar_player_close(void)
{
    av_log(NULL, AV_LOG_WARNING, "sstar_player_close start!\n");

    isplay->exit = true;
    pthread_join(isplay->playtid, NULL);
    
    if (st_index[AVMEDIA_TYPE_VIDEO] >= 0) {
        video_display_deinit();
        MI_DISP_DisableInputPort(0, 0);
        avcodec_free_context(&isplay->video_ctx);
    }

    if (st_index[AVMEDIA_TYPE_AUDIO] >= 0) {
        sstar_audio_deinit();
        avcodec_free_context(&isplay->audio_ctx);
    }

    if (isplay->img_ctx) {
        MI_SYS_Munmap(isplay->vir_addr, isplay->buf_size);
        MI_SYS_MMA_Free(isplay->phy_addr);
        sws_freeContext(isplay->img_ctx);
    }

    if (isplay->frm_yuv) {
        av_frame_free(&isplay->frm_yuv);
    }

    avformat_close_input(&isplay->fmt_ctx);
    av_freep(&isplay);

    //fclose(fp);
    av_log(NULL, AV_LOG_WARNING, "### sstar_player_close end ###\n");
    return 0;
}



