date 032912122020.12
mkdir /var/tmp
#echo 7M > /sys/block/zram0/disksize
#mkswap /dev/zram0
#swapon /dev/zram0
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/customer_app/lib:/customer_app/libsercurity:/lib:/config/lib:/config/wifi:/customer/lib
echo 12 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio12/direction
echo 1 >/sys/class/gpio/gpio12/value
echo 4 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio4/direction
echo 1 >/sys/class/gpio/gpio4/value
echo 5 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio5/direction
echo 1 >/sys/class/gpio/gpio5/value
echo 14 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio14/direction
echo 1 >/sys/class/gpio/gpio14/value
echo 73 >/sys/class/gpio/export
echo out >/sys/class/gpio/gpio73/direction
echo 1 >/sys/class/gpio/gpio73/value
rm -f /dev/random
ln -s /dev/urandom /dev/random
cd /customer_app
chmod 777 zkgui
./zkgui &
