/config/riu_w 101e 0xd 0x1000

date 032912122020.12

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/lib:/customer/lib
cd /customer
chmod 777 zkgui
./zkgui &


